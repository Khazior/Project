<?php
$host = "localhost";
$userdb = "root";
$password = "";
$namadb = "db_apotek";
// koneksi ke database
$koneksi = mysqli_connect($host, $userdb, $password, $namadb);
if (!$koneksi) {
    echo "<h2 style='color: red; text-align: center'>Database tidak terkoneksi!</h2>";
}
?>
<!-- else{
    echo "<h2 style='color: blue; text-align: center'>Database terkoneksi!</h2>";
} -->