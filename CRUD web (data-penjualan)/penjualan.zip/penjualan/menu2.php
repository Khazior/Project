<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link collapsed" href="index.php">
          <i class="bi bi-grid"></i>
          <span>Beranda</span>
        </a>
      </li><!-- End Dashboard Nav -->
      <li class="nav-item">
        <a class="nav-link" href="media.php?page=databarang">
        <i class="bi bi-journal-text"></i>
          <span>Daftar Barang</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="media.php?page=tambahbarang">
        <i class="bi bi-cart"></i>
          <span>Tambah Barang</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="media.php?page=ubah_barang">
        <i class="bi bi-pencil-square"></i>
          <span>Ubah Barang</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="media.php?page=hapus_barang">
        <i class="bi bi-trash"></i>
          <span>Hapus Barang</span>
        </a>
      </li>

  </aside><!-- End Sidebar-->