<main id="main" class="main">
<?php include "menu4.php"; ?>
<div class="pagetitle">
  <h1>Ubah Data Barang</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
      <li class="breadcrumb-item"><a href="media.php?page=databarang">Daftar barang</a></li>
      <li class="breadcrumb-item active">Ubah barang</li>
    </ol>
  </nav>
</div><!-- End Page Title -->
<?php
if (isset($_GET['kdbarang'])){
    $kdbarang=$_GET['kdbarang'];
    $tampil="SELECT * FROM tb_barang WHERE kdbarang='$kdbarang'";
    $qtampil=mysqli_query($koneksi,$tampil);
    $data=mysqli_fetch_array($qtampil);
}
?>
<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                  <h5 class="card-title">Ubah data barang</h5>
                <!-- General Form Elements -->
                <?php 
                    if(isset($_POST['ubah'])){
                        $nama_barang=$_POST['nama_brg'];
                        $jenis_barang=$_POST['jenis'];
                        $kondisi_barang=$_POST['kondisi'];
                        $harga_barang=$_POST['harga'];
                        $deskripsi_barang=$_POST['deskripsi'];
                        $foto=$_FILES['foto']['name'];
                        $tmp=$_FILES['foto']['tmp_name'];

                    // proses ubah dari database
                    if(strlen($foto)>0){
                        $input="UPDATE tb_barang SET nama_brg='$nama_barang', jenis='$jenis_barang', kondisi='$kondisi_barang', harga='$harga_barang', deskripsi='$deskripsi_barang', foto='$foto' WHERE kdbarang='$kdbarang'";
                        $query=mysqli_query($koneksi,$input);
                        move_uploaded_file($tmp,"C:/xampp/htdocs/penjualan2/penjualan/assets/img/$foto");
                    }else{
                        $input="UPDATE tb_barang SET nama_brg='$nama_barang', jenis='$jenis_barang', kondisi='$kondisi_barang', harga='$harga_barang', deskripsi='$deskripsi_barang' WHERE kdbarang='$kdbarang'";
                        $query=mysqli_query($koneksi, $input);
                    }
                    if($query){
                        echo "<div class='alert alert-success' role='alert'>
                        Data berhasil diubah! <a href='media.php?page=databarang'>lihat data</a>
                    </div>";
                    }else{
                        echo "<div class='alert alert-danger' role='alert'>
                        Data gagal diubah!
                    </div>";
                    }
                    }
                ?>
                <form method="POST" action="" enctype="multipart/form-data">
                    <div class="row mb-3">
                        <label for="inputText" class="col-sm-2 col-form-label">Kode barang</label>
                        <div class="col-sm-10">
                            <input type="text" name="kdbarang" value="<?php echo $data['kdbarang'];?>" class="form-control" disabled>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="inputText" class="col-sm-2 col-form-label">Nama Barang</label>
                        <div class="col-sm-10">
                            <input type="text" name="nama_brg" value="<?php echo $data['nama_brg'];?>" class="form-control">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label">Jenis Barang</label>
                        <div class="col-sm-10">
                            <select class="form-select" name="jenis" aria-label="Default select example">
                            <option value="Kendaraan" <?php if($data['jenis']=="Kendaraan") echo "selected";?>>Kendaraan</option>
                            <option value="Elektronik" <?php if($data['jenis']=="Elektronik") echo "selected";?>>Elektronik</option>
                            <option value="Pakaian" <?php if($data['jenis']=="Pakaian") echo "selected";?>>Pakaian</option>
                            </select>
                        </div>
                    </div>
                    <fieldset class="row mb-3">
                        <legend class="col-form-label col-sm-2 pt-0">Kondisi</legend>
                        <div class="col-sm-10">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="kondisi" id="kondisi" value="Baru" <?php if($data['kondisi']=="Baru") {echo "checked";}?>>
                                <label class="form-check-label" for="kondisi">Baru</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="kondisi" id="kondisi" value="Bekas" <?php if($data['kondisi']=="Bekas") {echo "checked";}?>>
                                <label class="form-check-label" for="kondisi">Bekas</label>
                            </div>
                        </div>
                    </fieldset>
                    <div class="row mb-3">
                        <label for="inputText" class="col-sm-2 col-form-label">Harga</label>
                        <div class="col-sm-10">
                            <input type="text" name="harga" value="<?php echo $data['harga'];?>" class="form-control">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="inputPassword" class="col-sm-2 col-form-label">Deskripsi</label>
                        <div class="col-sm-10">
                            <textarea class="form-control" name="deskripsi" style="height: 100px"><?php echo $data['deskripsi'];?></textarea>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="inputNumber" class="col-sm-2 col-form-label">File Upload</label>
                        <div class="col-sm-10">
                            <img src="assets/img/foto/<?php echo $data['foto'];?>" width="70" alt="foto-barang">
                            <input class="form-control" name="foto" type="file" id="formFile">
                        </div>
                    </div>               
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label"></label>
                        <div class="col-sm-10">
                            <button type="submit" name="ubah" class="btn btn-primary">Ubah</button>
                            <a href="media.php?page=databarang">
                            <input type="button" class="btn btn-warning" value="Batal"></a>
                        </div>
                    </div>
                </form> <!-- End General Form Elements -->
            </div>
        </div>
        </div>
    </div>
</section>

</main><!-- End #main -->