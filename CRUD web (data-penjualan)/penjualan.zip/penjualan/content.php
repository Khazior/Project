<?php
if (isset($_GET['page'])) {
    $page = $_GET['page']; 
    if (file_exists("$page.php")) {
        include "$page.php";
    } else {
        echo "<main id='main' class='main'>
        <div class='pagetitle'>
        <h3 style='text-align: center' >Halaman tidak ditemukan#404</h3>
        </div>
        </main>";
    }
} else {
    include "dashboard.php";
}
?>