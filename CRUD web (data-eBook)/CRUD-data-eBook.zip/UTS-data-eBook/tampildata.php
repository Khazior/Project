<?php
session_start();
if(isset($_SESSION['email']) && isset($_SESSION['level'])){
    include 'koneksi.php';
?>
<!doctype php>
<!--[if lt IE 7]>      <php class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <php class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <php class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<php class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Data ebook</title>
    <meta name="description" content="Sufee Admin - php5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="icon" href="images/kaziro.jpg">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="vendors/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
</head>

<body>
    <!-- Left Panel -->

    <?php include "tampil_leftpanel.php";?>

    <!-- Left Panel -->

    <!-- Right Panel -->

    <?php include "tampil_header.php";?>
    
        <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="index.php">Beranda</a></li>
                            <li class="active">Data ebook</li>
                            <li><a href="tambahdata.php">Tambah data</a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title" style="text-align: center;">Data ebook</h3>
                                <div class="col-md-5">
                                    <a href="tambahdata.php">
                                        <button type="button" class="btn btn-primary" style="border-radius: 5px;">Tambah data</button>
                                    </a>
                                </div>
                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>kode_ebook</th>
                                            <th>judul_ebook</th>
                                            <th>penulis</th>
                                            <th>bidang</th>
                                            <th>deskripsi</th>
                                            <th>file</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        include "koneksi.php";
                                        $tampil="SELECT * FROM buku_digital";
                                        $query=mysqli_query($koneksi,$tampil);
                                        while($data=mysqli_fetch_array($query)){
                                        ?>
                                        <tr>
                                            <td><?php echo $data['kode_ebook'];?></td>
                                            <td><?php echo $data['judul_ebook'];?></td>
                                            <td><?php echo $data['penulis'];?></td>
                                            <td><?php echo $data['bidang'];?></td>
                                            <td><?php echo $data['deskripsi'];?></td>
                                            <td><a href="images/file_diterima/<?php echo $data['file'];?>" download>
                                                <input type="button" value="Download"></a>
                                                <img src="images/file_diterima/<?php echo $data['file'];?>" alt="file" width="50"></td>
                                            <td>
                                                <a href="ubahdata.php?page=ubahdata&kode_ebook=<?php echo $data['kode_ebook'];?>">
                                                    <button type="button" style="border-radius: 5px;" class="btn btn-warning menu-icon fa fa-edit" ></button></a>
                                                <a href="javascript:if(confirm('Yakin Ingin Menghapus Data?')){document.location='hapusbarang.php?kode_ebook=<?php echo $data['kode_ebook'];?>';}">
                                                    <button type="button" style="border-radius: 5px;" class="btn btn-danger menu-icon fa fa-trash" ></button></a>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- .animated -->
        </div><!-- .content -->
    </div><!-- /#right-panel -->

    <!-- Right Panel -->
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>

    <script src="vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="vendors/jszip/dist/jszip.min.js"></script>
    <script src="vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="vendors/pdfmake/build/vfs_fonts.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.php5.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>
    <script src="assets/js/init-scripts/data-table/datatables-init.js"></script>

</body>

</php>
<?php
}else{
    echo "<h3 align='center' style='color: red'>anda sudah logout, silahkan <a href='login.php'>login!";
}
?>