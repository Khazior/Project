<?php
$host = "localhost";
$userdb = "root";
$password = "";
$namadb = "dbpenjualan";
// koneksi ke database
$koneksi = mysqli_connect($host, $userdb, $password, $namadb);
if (!$koneksi) {
    echo "Database tidak terkoneksi";
}
?>
