<main id="main" class="main">
<?php include "menu5.php";?>

<div class="pagetitle">
  <h1>Mode Hapus Barang</h1>
  <nav>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
        <li class="breadcrumb-item"><a href="media.php?page=databarang">Data barang</a></li>
        <li class="breadcrumb-item"><a href="media.php?page=tambahbarang">Tambah barang</a></li>
        <li class="breadcrumb-item"><a href="media.php?page=ubah_barang">Ubah barang</a></li>
        <li class="breadcrumb-item active">Hapus barang</li>
    </ol>
  </nav>
</div><!-- End Page Title -->

<section class="section">
  <div class="row">
    <div class="col-lg-12">

      <div class="card">
        <div class="card-body">
            <h4 style="text-align: center;" class="card-title">Pilih data yang ingin dihapus<br>pada bagian aksi</h4>
            <h5 class="card-title">Daftar Barang</h5>
          <!-- Table with stripped rows -->
          <table id="example" class="table">
            <thead>
              <tr>
                <th>Kode</th>
                <th>Foto</th>
                <th>Nama</th>
                <th>Jenis</th>
                <th>Kondisi</th>
                <th>Harga</th>
                <th>Deskripsi</th>
                <!-- <th>Deskripsi</th> -->
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
            <?php
            $tampil="SELECT * FROM tb_barang";
            $query=mysqli_query($koneksi,$tampil);
            while($data=mysqli_fetch_array($query)){
              $harga="Rp. ".number_format($data['harga'],0,',','.');
              ?>
              <tr>
                <td><?php echo $data['kdbarang'];?></td>
                <td><img src="assets/img/foto/<?php echo $data['foto'];?>" width="70px" alt="fto-produk"></td>
                <td><?php echo $data['nama_brg'];?></td>
                <td><?php echo $data['jenis'];?></td>
                <td><?php echo $data['kondisi'];?></td>
                <td><?php echo $harga?></td>
                <td><?php echo $data['deskripsi'];?></td>
                <!-- <td>Ditenagai prosesor Snapdragon 888.</td> -->
                <td>
                  <a href="javascript:if(confirm('Yakin ingin menghapus data?')){document.location='hapusbarang.php?kdbarang=<?php echo $data['kdbarang'];?>';}"><button type="submit" class="btn btn-danger"><i class="bi bi-trash"></i></button></a>
                </td>
              </tr>
              <?php } ?>
            </tbody>
          </table>
          <!-- End Table with stripped rows -->
        </div>
      </div>
    </div>
  </div>
</section>

</main><!-- End #main -->

<!-- Include jQuery and DataTables JS/CSS files -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">

<!-- Initialize DataTable -->
<script>
$(document).ready(function() {
    $('#example').DataTable({
        "paging": false,            // Disable pagination
        "info": false,              // Disable info text ("Showing X to Y of Z entries")
        "lengthChange": false,      // Disable entries per page dropdown
        "searching": true           // Keep search functionality
    });
});
</script>