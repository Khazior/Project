<?php
session_start();
if(isset($_SESSION['email']) && isset($_SESSION['level'])){
    include '../koneksi.php';
    if(isset($_GET['kodebuku'])){
        $kodebuku = $_GET['kodebuku'];
        $hapus = "DELETE FROM buku WHERE kodebuku = '$kodebuku'";
        $qhapus = mysqli_query($koneksi, $hapus);
            if($qhapus){
                header("location:tabel.php");
            }else{
                echo "Data gagal dihapus!";
            }
        }
}else{
    echo "<h3 align='center' style='color: red;'>anda tidak boleh masuk/sudah logout di halaman ini! <a href='../login.php'>login!</a></h3>";
}
?>