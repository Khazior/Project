<?php
session_start();
if(isset($_SESSION['email']) && isset($_SESSION['level'])){
    include 'koneksi.php';
?>
<!doctype php>
<!--[if lt IE 7]>      <php class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <php class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <php class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<php class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Tambah data</title>
    <meta name="description" content="form yang akan menampilkan pengisian data mahasiswa">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="icon" href="images/kaziro.jpg">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">


    <link rel="stylesheet" href="vendors/chosen/chosen.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body>
    <!-- Left Panel -->

    <?php include "tambah_leftpanel.php";?>

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
            
            <?php include "tambah_header.php";?>

        <!-- Header-->

        <!-- navigasi pindah panel -->
        <div class="breadcrumbs">
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="index.php">Beranda</a></li>
                            <li><a href="tampildata.php">Data ebook</a></li>
                            <li class="active">Tambah data</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

            <div class="content mt-3">
                <div class="animated fadeIn">
                    
                    <div class="row">
                        
                        <div class="col-xs-12 col-sm-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 style="text-align: center;" >Tambah data ebook</h3>
                                </div>
                                <!-- form tambah data -->
                                <?php
                                    if(isset($_POST['simpan'])){
                                        include "koneksi.php";
                                        $kode = $_POST['kode_ebook'];
                                        $judul = $_POST['judul_ebook'];
                                        $penulis = $_POST['penulis'];
                                        $bidang = $_POST['bidang'];
                                        $deskripsi = $_POST['deskripsi'];
                                        $file=$_FILES['file']['name'];
                                        $tmp=$_FILES['file']['tmp_name'];
                                        
                                        $input_data = "INSERT INTO buku_digital VALUES ('$kode','$judul','$penulis','$bidang','$deskripsi','$file')";
                                        $query = mysqli_query($koneksi, $input_data);
                                        move_uploaded_file($tmp, "images/file_diterima/$file");
                                        if($query){
                                            echo "<div class='alert alert-success' role='alert'>
                                            Data berhasil ditambahkan! <a href='tampildata.php'>lihat data</a>
                                            </div>";
                                        }else{
                                            echo "<div class='alert alert-danger' role='alert'>
                                            Data gagal disimpan!
                                            </div>";
                                        }
                                    }
                                ?>
                                <form method="post" action="" enctype="multipart/form-data">
                                    <div class="card-body card-block">
                                        <div class="form-group">
                                            <label class=" form-control-label">Kode ebook</label>
                                            <div class="input-group">
                                                <div class="input-group-addon"><i class="fa fa-male"></i></div>
                                                <input type="text" class="form-control" name="kode_ebook">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class=" form-control-label">Judul ebook</label>
                                            <div class="input-group">
                                                <div class="input-group-addon"><i class="fa fa-asterisk"></i></div>
                                                <input type="text" class="form-control" name="judul_ebook">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class=" form-control-label">Penulis</label>
                                            <div class="input-group">
                                                <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
                                                <input type="text" class="form-control" name="penulis">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class=" form-control-label">Bidang</label>
                                            <select class="form-select" name="bidang">
                                                <option value="Kedokteran">Kedokteran</option>
                                                <option value="Ilmu teknologi">Ilmu teknologi</option>
                                                <option value="Keguruan">Keguruan</option>
                                                <option value="Ekonomi">Ekonomi</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class=" form-control-label">Deskripsi</label>
                                            <div class="input-group">
                                                <div class="input-group-addon"><i class="fa fa-map"></i></div>
                                                <textarea name="deskripsi" class="form-control" id=""></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class=" form-control-label">File</label>
                                            <div class="input-group">
                                                <div class="input-group-addon"><i class="fa fa-book"></i></div>
                                                <input type="file" class="form-control" name="file">
                                            </div>
                                        </div>
                                        <div class="row mb-0">
                                            <label class="col-sm-0 col-form-label"></label>
                                            <div class="col-sm-10">
                                                <button type="submit" name="simpan" class="btn btn-primary" style="border-radius: 5px;">Submit</button>
                                                <a href="tampildata.php">
                                                    <input type="button" class="btn btn-warning"  style="border-radius: 5px;" value="Batal"></button>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- .animated -->
    </div><!-- .content -->

<script src="vendors/jquery/dist/jquery.min.js"></script>
<script src="vendors/popper.js/dist/umd/popper.min.js"></script>
<script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="vendors/chosen/chosen.jquery.min.js"></script>

<script>
    jQuery(document).ready(function() {
        jQuery(".standardSelect").chosen({
            disable_search_threshold: 10,
            no_results_text: "Oops, nothing found!",
            width: "100%"
        });
    });
</script>

</body>

</php>
<?php
}else{
    echo "<h3 align='center' style='color: red'>anda sudah logout, silahkan <a href='login.php'>login!";
}
?>