<?php
session_start();
if(isset($_SESSION['email']) && isset($_SESSION['level'])){
    include '../koneksi.php';
    if(isset($_GET['id_obat'])){
        $id_obat = $_GET['id_obat'];
        $hapus = "DELETE FROM obat WHERE id_obat = '$id_obat'";
        $qhapus = mysqli_query($koneksi, $hapus);
            if($qhapus){
                header("location:tabel_obat.php");
            }else{
                echo "Data gagal dihapus!";
            }
        }
}else{
    echo "<h3 align='center' style='color: red;'>anda sudah logout, silahkan <a href='../login.php'>login!";
}
?>