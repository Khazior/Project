<!doctype php>
<!--[if lt IE 7]>      <php class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <php class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <php class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<php class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Tambah data</title>
    <meta name="description" content="form yang akan menampilkan pengisian data mahasiswa">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="icon" href="images/kaziro.jpg">


    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">


    <link rel="stylesheet" href="vendors/chosen/chosen.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>



</head>

<body>
    <!-- Left Panel -->

    <?php include "tambah_leftpanel.php";?>

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
            
            <?php include "tambah_header.php";?>

        <!-- Header-->

        <!-- navigasi pindah panel -->
        <div class="breadcrumbs">
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="index.php">Beranda</a></li>
                            <li><a href="tampildata.php">Data mahasiswa</a></li>
                            <li class="active">Tambah data</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <!-- form tambah data -->
        <?php
            if(isset($_POST['simpan'])){
                include "koneksi.php";
                $nama = $_POST['nama_mhs'];
                $nim = $_POST['nim_mhs'];
                $prodi = $_POST['program_studi'];
                $semester_mhs = $_POST['semester'];
                $alamat = $_POST['alamat_mhs'];
                $telepon = $_POST['no_telepon'];

                $input_data = "INSERT INTO data_mahasiswa VALUES ('$nama','$nim','$prodi','$semester_mhs','$alamat','$telepon')";
                $query = mysqli_query($koneksi, $input_data);
                if($query){
                    echo "<div class='alert alert-success' role='alert'>
                    Data berhasil ditambahkan! <a href='tampildata.php'>lihat data</a>
                    </div>";
                }else{
                    echo "<div class='alert alert-danger' role='alert'>
                    Data gagal disimpan!
                    </div>";
                }
            }
        ?>
            <div class="content mt-3">
                <div class="animated fadeIn">
                    
                    <div class="row">
                        
                        <div class="col-xs-12 col-sm-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 style="text-align: center;" >Tambah data mahasiswa</h3>
                                </div>
                                <form method="post" action="" enctype="multipart/form-data">
                                    <div class="card-body card-block">
                                        <div class="form-group">
                                            <label class=" form-control-label">Nama mahasiswa</label>
                                            <div class="input-group">
                                                <div class="input-group-addon"><i class="fa fa-male"></i></div>
                                                <input type="text" class="form-control" name="nama_mhs">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class=" form-control-label">Nim mahasiswa</label>
                                            <div class="input-group">
                                                <div class="input-group-addon"><i class="fa fa-asterisk"></i></div>
                                                <input type="text" class="form-control" name="nim_mhs">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class=" form-control-label">Program studi</label>
                                            <div class="input-group">
                                                <div class="input-group-addon"><i class="fa fa-calendar"></i></div>
                                                <input type="text" class="form-control" name="program_studi">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class=" form-control-label">Semester</label>
                                            <select class="form-select" name="semester">
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                                <option value="6">6</option>
                                                <option value="7">7</option>
                                                <option value="8">8</option>
                                                <option value="9">9</option>
                                                <option value="10">10</option>
                                                <option value="11">11</option>
                                                <option value="12">12</option>
                                                <option value="13">13</option>
                                                <option value="14">14</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class=" form-control-label">Alamat mahasiswa</label>
                                            <div class="input-group">
                                                <div class="input-group-addon"><i class="fa fa-map"></i></div>
                                                <input type="text" class="form-control" name="alamat_mhs">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class=" form-control-label">No telepon</label>
                                            <div class="input-group">
                                                <div class="input-group-addon"><i class="fa fa-phone"></i></div>
                                                <input type="text" class="form-control" name="no_telepon">
                                            </div>
                                        </div>
                                        <div class="row mb-0">
                                            <label class="col-sm-0 col-form-label"></label>
                                            <div class="col-sm-10">
                                                <button type="submit" name="simpan" class="btn btn-primary" style="border-radius: 5px;">Submit</button>
                                                <a href="tampildata.php">
                                                    <input type="button" class="btn btn-warning"  style="border-radius: 5px;" value="Batal"></button>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- .animated -->
    </div><!-- .content -->

<script src="vendors/jquery/dist/jquery.min.js"></script>
<script src="vendors/popper.js/dist/umd/popper.min.js"></script>
<script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="vendors/chosen/chosen.jquery.min.js"></script>

<script>
    jQuery(document).ready(function() {
        jQuery(".standardSelect").chosen({
            disable_search_threshold: 10,
            no_results_text: "Oops, nothing found!",
            width: "100%"
        });
    });
</script>

</body>

</php>
