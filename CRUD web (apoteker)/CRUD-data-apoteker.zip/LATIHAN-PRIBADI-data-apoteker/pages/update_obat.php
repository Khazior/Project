<?php
session_start();
if(isset($_SESSION['email']) && isset($_SESSION['level'])){
    include '../koneksi.php';
?>
<!doctype php>
<php lang="en">

 
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Form Validation</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="../assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/libs/css/style.css">
    <link rel="stylesheet" href="../assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
</head>

<body>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
         <!-- ============================================================== -->
        <!-- navbar -->
        <!-- ============================================================== -->
         <div class="dashboard-header">
            <nav class="navbar navbar-expand-lg bg-white fixed-top">
                <a class="navbar-brand" href="../index.php">Concept</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse " id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto navbar-right-top">
                        <li class="nav-item">
                            <div id="custom-search" class="top-search-bar">
                                <input class="form-control" type="text" placeholder="Search..">
                            </div>
                        </li>
                        <li class="nav-item dropdown notification">
                            <a class="nav-link nav-icons" href="#" id="navbarDropdownMenuLink1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-fw fa-bell"></i> <span class="indicator"></span></a>
                            <ul class="dropdown-menu dropdown-menu-right notification-dropdown">
                                <li>
                                    <div class="notification-title"> Notification</div>
                                    <div class="notification-list">
                                        <div class="list-group">
                                            <a href="#" class="list-group-item list-group-item-action active">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img src="../assets/images/avatar-2.jpg" alt="" class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span class="notification-list-user-name">Jeremy Rakestraw</span>accepted your invitation to join the team.
                                                        <div class="notification-date">2 min ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img src="../assets/images/avatar-3.jpg" alt="" class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span class="notification-list-user-name">
John Abraham</span>is now following you
                                                        <div class="notification-date">2 days ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img src="../assets/images/avatar-4.jpg" alt="" class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span class="notification-list-user-name">Monaan Pechi</span> is watching your main repository
                                                        <div class="notification-date">2 min ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img src="../assets/images/avatar-5.jpg" alt="" class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span class="notification-list-user-name">Jessica Caruso</span>accepted your invitation to join the team.
                                                        <div class="notification-date">2 min ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="list-footer"> <a href="#">View all notifications</a></div>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown connection">
                            <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="fas fa-fw fa-th"></i> </a>
                            <ul class="dropdown-menu dropdown-menu-right connection-dropdown">
                                <li class="connection-list">
                                    <div class="row">
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/github.png" alt="" > <span>Github</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/dribbble.png" alt="" > <span>Dribbble</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/dropbox.png" alt="" > <span>Dropbox</span></a>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/bitbucket.png" alt=""> <span>Bitbucket</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/mail_chimp.png" alt="" ><span>Mail chimp</span></a>
                                        </div>
                                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 ">
                                            <a href="#" class="connection-item"><img src="../assets/images/slack.png" alt="" > <span>Slack</span></a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="conntection-footer"><a href="#">More</a></div>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown nav-user">
                            <a class="nav-link nav-user-img" href="#" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="../assets/images/avatar-1.jpg" alt="" class="user-avatar-md rounded-circle"></a>
                            <div class="dropdown-menu dropdown-menu-right nav-user-dropdown" aria-labelledby="navbarDropdownMenuLink2">
                                <div class="nav-user-info">
                                    <h5 class="mb-0 text-white nav-user-name">
John Abraham</h5>
                                    <span class="status"></span><span class="ml-2">Available</span>
                                </div>
                                <a class="dropdown-item" href="#"><i class="fas fa-user mr-2"></i>Account</a>
                                <a class="dropdown-item" href="#"><i class="fas fa-cog mr-2"></i>Setting</a>
                                <a class="dropdown-item" href="#"><i class="fas fa-power-off mr-2"></i>Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <!-- ============================================================== -->
        <!-- end navbar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- left sidebar -->
        <!-- ============================================================== -->
        <div class="nav-left-sidebar sidebar-dark">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav flex-column">
                            <li class="nav-divider">
                                Menu
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="../index.php" aria-expanded="false"><i class="fa fa-fw fa-user-circle"></i>Dashboard<span class="badge badge-success"></span></a>
                                <div id="submenu-1" class="collapse submenu">
                                </div>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="form_obat.php" aria-expanded="false"><i class="fab fa-fw fa-wpforms"></i>Form tambah obat</a>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link active" href="tabel_obat.php" aria-expanded="false"><i class="fas fa-fw fa-table"></i>Tabel obat</a>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="form_penjualan.php" aria-expanded="false"><i class="fab fa-fw fa-wpforms"></i>Form pembelian obat</a>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="tabel_penjualan.php" aria-expanded="false"><i class="fas fa-fw fa-table"></i>History pembelian obat</a>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="../logout.php" aria-expanded="false"><i class="fas fa-fw fa fa-trash"></i>logout</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end left sidebar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
        <div class="dashboard-wrapper">
            <div class="container-fluid  dashboard-content">
                <!-- ============================================================== -->
                <!-- pageheader -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h2 class="pageheader-title">Formulir</h2>
                            <div class="page-breadcrumb">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item active"><a href="tabel_obat.php" class="breadcrumb-link">Update tabel obat</a></li>
                                        <li class="breadcrumb-item"><a href="form_penjualan.php" class="breadcrumb-link">Form pembelian obat</a></li>
                                        <li class="breadcrumb-item"><a href="tabel_penjualan.php" class="breadcrumb-link">History pembelian obat</a></li>
                                        <li class="breadcrumb-item"><a href="form_obat.php" class="breadcrumb-link">Form tambah obat</a></li>
                                        <li class="breadcrumb-item"><a href="index.php" class="breadcrumb-link">Dashboard</a></li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end pageheader -->
                <!-- ============================================================== -->
                    <?php
                    include '../koneksi.php';
                    if(isset($_GET['id_obat'])){
                        $id_obat = $_GET['id_obat'];
                        $sql = "SELECT * FROM obat WHERE id_obat = '$id_obat'";
                        $query = mysqli_query($koneksi, $sql);
                        $data = mysqli_fetch_array($query);
                    }
                    ?>
                    <div class="row">
                        <!-- ============================================================== -->
                        <!-- validation form -->
                        <!-- ============================================================== -->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h3 class="card-header" style="text-align: center;">Form Tambah Obat
                                    <button type="button" class="btn btn-space btn-secondary" style="float: right; border-radius: 5px;">
                                        <a href="tabel_obat.php" style="color: white;">kembali</a>
                                    </button>
                                </h3>
                                <div class="card-body">
                                    <?php
                                    include '../koneksi.php';
                                        if(isset($_POST['simpan'])){
                                            $nama_obat = $_POST['nama_obat'];
                                            $harga_obat = $_POST['harga_obat'];
                                            $stok_obat = $_POST['stok_obat'];
                                            $id_kategori = $_POST['id_kategori'];
                                            $khasiat = $_POST['khasiat'];
                                            $expired = $_POST['expired'];

                                            $input = "UPDATE obat SET nama_obat='$nama_obat', harga_obat='$harga_obat', stok_obat='$stok_obat', id_kategori='$id_kategori', khasiat='$khasiat', expired='$expired' WHERE id_obat='$id_obat'";
                                            $query = mysqli_query($koneksi, $input);
                                            if($query){
                                                echo "<div class='alert alert-success' role='alert'>
                                                Obat berhasil diubah! <a href='tabel_obat.php'>lihat data</a>
                                                </div>";
                                            }else{
                                                echo "<div class='alert alert-danger' role='alert'>
                                                Obat gagal diubah!
                                                </div>";
                                            }
                                        }
                                    ?>
                                    <form method="POST" class="needs-validation" enctype="multipart/form-data">
                                        <div class="row">
                                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                                <label for="validationCustom01">id obat</label>
                                                <input type="text" class="form-control" name="id_obat" value="<?php echo $data['id_obat'];?>" id="validationCustom01" readonly>
                                                <div class="invalid-feedback">
                                                    id diperlukan!
                                                </div>
                                            </div>
                                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 "> <br>
                                                <label for="validationCustom02">nama obat</label>
                                                <input type="text" class="form-control" name="nama_obat" value="<?php echo $data['nama_obat'];?>" id="validationCustom02" required>
                                                <div class="invalid-feedback">
                                                    nama diperlukan!
                                                </div>
                                            </div>
                                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 "> <br>
                                                <label for="validationCustom03">harga obat</label>
                                                <input type="number" class="form-control" name="harga_obat" value="<?php echo $data['harga_obat'];?>" id="validationCustom03" min="0" required>
                                            </div>
                                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 "> <br>
                                                <label for="validationCustom04">stok obat</label>
                                                <input type="number" class="form-control" name="stok_obat" value="<?php echo $data['stok_obat'];?>" id="validationCustom04" min="0" required>
                                            </div>
                                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 "> <br>
                                                <label for="validationCustom05">kategori</label>
                                                <select id="validationCustom05" name="id_kategori" class="form-control">
                                                    <?php
                                                        $kategori_relasi = "SELECT * FROM kategori";
                                                        $a = mysqli_query($koneksi, $kategori_relasi);
                                                        while($b = mysqli_fetch_array($a)){
                                                            $choose = ($data['id_kategori'] == $b['id_kategori']) ? "selected":"";
                                                            echo "<option value='{$b['id_kategori']}' {$choose}>{$b['nama_kategori']}</option>";
                                                        }
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 "> <br>
                                                <label for="validationCustom06">khasiat</label>
                                                <input type="text" class="form-control" name="khasiat" value="<?php echo $data['khasiat'];?>" id="validationCustom06" required>
                                                <div class="invalid-feedback">
                                                    informasi khasiat dibutuhkan!
                                                </div>
                                            </div>
                                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 "> <br>
                                                <label for="validationCustom07">expired</label>
                                                <input type="date" class="form-control" name="expired" value="<?php echo $data['expired'];?>" id="validationCustom07" required>
                                                <div class="invalid-feedback">
                                                    tanggal expired dibutuhkan!
                                                </div> <br>
                                                <button type="submit" name="simpan" class="btn btn-space btn-primary" style="border-radius: 5px;">
                                                    Submit
                                                </button>
                                                <button type="reset" class="btn btn-space btn-secondary" style="border-radius: 5px;">
                                                    Reset
                                                </button>
                                            </div>
                                        </div>
                                        </form>
                                    </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end validation form -->
                        <!-- ============================================================== -->
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- footer -->
                <!-- ============================================================== -->
                <div class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                                Hak cipta © 2024 Kaziro. Seluruh hak cipta.</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- end footer -->
                <!-- ============================================================== -->
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end main wrapper -->
        <!-- ============================================================== -->
        <!-- Optional JavaScript -->
        <script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
        <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
        <script src="../assets/vendor/slimscroll/jquery.slimscroll.js"></script>
        <script src="../assets/vendor/parsley/parsley.js"></script>
        <script src="../assets/libs/js/main-js.js"></script>
        <script>
    $('#form').parsley();
    </script>
    <script>
    // Example starter JavaScript for disabling form submissions if there are invalid fields
    (function() {
        'use strict';
        window.addEventListener('load', function() {
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.getElementsByClassName('needs-validation');
            // Loop over them and prevent submission
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();
    </script>
</body>
<?php
}else{
    echo "<h3 align='center' style='color: red'>anda sudah logout, silahkan <a href='../login.php'>login!";
}
?>

<!-- Password -->
<!-- </php>
<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 "> <br>
<label for="validationCustom05">Password</label>
<input type="password" class="form-control" name="" id="validationCustom05" required>
<div class="invalid-feedback">
    Password dibutuhkan!
</div>
</div> -->

<!-- Jumlah -->
