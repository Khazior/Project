<?php
session_start();
if(isset($_SESSION['email']) && isset($_SESSION['level'])){
    include "koneksi.php";
    if (isset($_GET['kode_ebook'])){
        $kode=$_GET['kode_ebook'];
        $hapus="DELETE FROM buku_digital WHERE kode_ebook='$kode'";
        $qhapus=mysqli_query($koneksi,$hapus);
        if($qhapus){
            header("location:tampildata.php");
        }else{
            echo "Data gagal dihapus!";
        }
    }  
}else{
    echo "<h3 align='center' style='color: red'>anda sudah logout, silahkan <a href='login.php'>login!";
}
?>