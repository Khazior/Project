# Aplikasi CRUD Mahasiswa Berbasis Web

Tugas yang saya lakukan hanya integrasi database MySQL dengan Php 
dan memodif isinya sehingga aplikasi CRUD bisa saya buat

Aplikasi ini merupakan sebuah aplikasi CRUD (Create, Read, Update, Delete) sederhana
untuk mengelola data mahasiswa. Aplikasi ini dibangun menggunakan framework Bootstrap
untuk tampilan antarmuka yang responsif dan modern.

## Fitur

- Menampilkan daftar mahasiswa
- Menambah data mahasiswa baru
- Mengubah data mahasiswa yang sudah ada
- Menghapus data mahasiswa

## Teknologi yang Digunakan

- HTML, CSS, JavaScript
- Bootstrap 4
- PHP
- MySQL

## Persyaratan

- Web server (localhost)
- PHP
- MySQL