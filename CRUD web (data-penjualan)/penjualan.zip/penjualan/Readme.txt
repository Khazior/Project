Koneksi ke database berbasis web dengan PHP dan MySql
Membuat program CRUD (Create, Read, Update, Delete) dengan PHP dan MySql
- mendownload aplikasi Python dan XAMPP untuk database servernya
- sebelum menjalankan programnya disarankan untuk import database yang sudah ada
  import ke database baru dengan nama dbpenjualan
- taruh folder projects ini di dalam folder htdocs yang ada di folder xampp C:\xampp\htdocs
- nyalakan Apache dan MySql dari aplikasi XAMPP dan 
  jalankan kodenya di index.php dengan live server