<main id="main" class="main">
<?php include "menu3.php";?>

<div class="pagetitle">
  <h1>Tambah barang</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
      <li class="breadcrumb-item"><a href="media.php?page=databarang">Daftar barang</a></li>
      <li class="breadcrumb-item active">Tambah barang</li>
    </ol>
  </nav>
</div><!-- End Page Title -->

<section class="section">
  <div class="row">
    <div class="col-lg-13">

      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Tambahkan data barang</h5>

          <!-- General Form Elements -->
          <?php 
            if(isset($_POST['simpan'])){
              $kd_barang=$_POST['kdbarang'];
              $nama_barang=$_POST['nama_brg'];
              $jenis_barang=$_POST['jenis'];
              $kondisi_barang=$_POST['kondisi'];
              $harga_barang=$_POST['harga'];
              $deskripsi_barang=$_POST['deskripsi'];
              $foto=$_FILES['foto']['name'];
              $tmp=$_FILES['foto']['tmp_name'];

              // proses input ke database
              $input="INSERT INTO tb_barang VALUES ('$kd_barang','$nama_barang','$jenis_barang','$kondisi_barang','$harga_barang','$deskripsi_barang','$foto')";
              $query=mysqli_query($koneksi,$input);
              move_uploaded_file($tmp, "./assets/img/foto/$foto");
              if($query){
                echo "<div class='alert alert-success' role='alert'>
                Data berhasil ditambahkan! <a href='media.php?page=databarang'>lihat data</a>
              </div>";
              }else{
                echo "<div class='alert alert-danger' role='alert'>
                Data gagal ditambahkan!
              </div>";
              }
            }
          ?>

          <form method="POST" action="" enctype="multipart/form-data">
            <div class="row mb-3">
              <label for="inputText" class="col-sm-2 col-form-label">Kode barang</label>
              <div class="col-sm-10">
                <input type="text" name="kdbarang" class="form-control">
              </div>
            </div>
            <div class="row mb-3">
              <label for="inputText" class="col-sm-2 col-form-label">Nama Barang</label>
              <div class="col-sm-10">
                <input type="text" name="nama_brg" class="form-control">
              </div>
            </div>
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label">Jenis Barang</label>
              <div class="col-sm-10">
                <select class="form-select" name="jenis" aria-label="Default select example">
                  <option value="Kendaraan">Kendaraan</option>
                  <option value="Elektronik" selected>Elektronik</option>
                  <option value="Pakaian">Pakaian</option>
                </select>
              </div>
            </div>
            <fieldset class="row mb-3">
                  <legend class="col-form-label col-sm-2 pt-0">Kondisi</legend>
                  <div class="col-sm-10">
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="kondisi" id="kondisi" value="Baru" checked>
                      <label class="form-check-label" for="kondisi">Baru</label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="kondisi" id="kondisi" value="Bekas">
                      <label class="form-check-label" for="kondisi">Bekas</label>
                    </div>
                  </div>
                </fieldset>
            <div class="row mb-3">
              <label for="inputText" class="col-sm-2 col-form-label">Harga</label>
              <div class="col-sm-10">
                <input type="text" name="harga" class="form-control">
              </div>
            </div>
            <div class="row mb-3">
              <label for="inputPassword" class="col-sm-2 col-form-label">Deskripsi</label>
              <div class="col-sm-10">
                <textarea class="form-control" name="deskripsi" style="height: 100px"></textarea>
              </div>
            </div>
            <div class="row mb-3">
              <label for="inputNumber" class="col-sm-2 col-form-label">File Upload</label>
              <div class="col-sm-10">
                <input class="form-control" name="foto" type="file" id="formFile">
              </div>
            </div>               
            </div>
            </fieldset>
            <div class="row mb-3">
              <label class="col-sm-2 col-form-label"></label>
              <div class="col-sm-10">
                <button type="submit" name="simpan" class="btn btn-primary">Submit</button>
                <button type="submit" name="batal" class="btn btn-warning">Batal</button>
              </div>
            </div>

          </form><!-- End General Form Elements -->

        </div>
      </div>

    </div>

    

    </div>
  </div>
</section>

</main><!-- End #main -->