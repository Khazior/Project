<?php
include "koneksi.php";
if (isset($_GET['kdbarang'])){
    $kdbarang=$_GET['kdbarang'];
    $hapus="DELETE FROM tb_barang WHERE kdbarang='$kdbarang'";
    $qhapus=mysqli_query($koneksi,$hapus);
    if($qhapus){
        header("location:media.php?page=databarang");
    }else{
        echo "Data gagal dihapus!";
    }
}
?>