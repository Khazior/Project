<?php
$host = "localhost";
$userdb = "root";
$password = "";
$namadb = "dbmahasiswa";
// koneksi ke database
$koneksi = mysqli_connect($host, $userdb, $password, $namadb);
if (!$koneksi) {
    echo "<div class='alert alert-danger' role='alert'>Database tidak terkoneksi</div>";
}
?>
