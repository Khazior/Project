<?php
include "koneksi.php";
if (isset($_GET['nim_mhs'])){
    $nim_mhs=$_GET['nim_mhs'];
    $hapus="DELETE FROM data_mahasiswa WHERE nim_mhs='$nim_mhs'";
    $qhapus=mysqli_query($koneksi,$hapus);
    if($qhapus){
        header("location:tampildata.php");
    }else{
        echo "Data gagal dihapus!";
    }
}
?>